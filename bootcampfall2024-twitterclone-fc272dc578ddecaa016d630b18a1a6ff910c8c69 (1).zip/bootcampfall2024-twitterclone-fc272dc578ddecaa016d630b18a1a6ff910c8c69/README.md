# Twitter Clone! 

Hey everyone! I hope you all enjoyed our React lecture. This week you will be creating a Twitter Clone! 

￼![Twitter Clone](https://github.com/user-attachments/assets/b1c8bbdf-cd7f-4e25-be7d-596758f4470a)


In this project you will be practicing creating components, passing down props, conditional rendering, and using state! You do not need to add the functionality to create new tweets or comments, you simply need to display the tweets on the screen and have the ability to like and unlike the tweets. Good luck!
