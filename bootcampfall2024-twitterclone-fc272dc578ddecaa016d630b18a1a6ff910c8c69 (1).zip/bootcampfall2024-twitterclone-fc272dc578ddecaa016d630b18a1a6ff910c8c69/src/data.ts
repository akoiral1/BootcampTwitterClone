export const tweetsData = [
  { id: 1, username: "alice", content: "Just setting up my Twitter clone!", likes: 5, timestamp: "2h" },
  { id: 2, username: "bob", content: "Loving React so far!", likes: 10, timestamp: "4h" },
  { id: 3, username: "charlie", content: "This is a great project for learning.", likes: 3, timestamp: "1d" },
  { id: 4, username: "dave", content: "Anyone else excited for the new React features?", likes: 12, timestamp: "3d" },
  { id: 5, username: "eve", content: "I love creating mock data. 😊", likes: 8, timestamp: "5d" },
  { id: 6, username: "frank", content: "Trying out some cool CSS animations today!", likes: 7, timestamp: "6h" },
  { id: 7, username: "grace", content: "JavaScript is tricky, but I'm getting the hang of it!", likes: 15, timestamp: "8h" },
  { id: 8, username: "hannah", content: "Any tips for optimizing React apps?", likes: 6, timestamp: "12h" },
  { id: 9, username: "ivan", content: "Finally nailed that bug in my code. Feels great!", likes: 11, timestamp: "1d" },
  { id: 10, username: "julia", content: "React Hooks make life so much easier!", likes: 20, timestamp: "2d" },
  { id: 11, username: "kevin", content: "Working on my first JavaScript game!", likes: 9, timestamp: "1h" },
  { id: 12, username: "laura", content: "Frontend development is so rewarding.", likes: 14, timestamp: "1d" },
  { id: 13, username: "mike", content: "Struggling a bit with Redux... any resources?", likes: 5, timestamp: "3d" },
  { id: 14, username: "nina", content: "Exploring async functions in JavaScript.", likes: 7, timestamp: "4d" },
  { id: 15, username: "owen", content: "Taking my coding skills to the next level!", likes: 12, timestamp: "5d" }
];
